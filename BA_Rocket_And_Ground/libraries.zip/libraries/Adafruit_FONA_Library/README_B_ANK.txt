by brady ankenbrandt

make sure to turn debug off in the config

you also have to edit the Adafruit_FONA.cpp as follows:

in the Adafruit_FONA::getGPS(float *lat, ...) function,

change the rounding factor from 100 to 10000
because whoever wrote this code was insane